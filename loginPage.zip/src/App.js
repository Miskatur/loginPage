import './App.css';
import LoginPage from './modal/LoginPage';

function App() {
  return (
    <div>
      <LoginPage></LoginPage>
    </div>
  );
}

export default App;
